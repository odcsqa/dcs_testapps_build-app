module.exports = function (grunt) {

    require("load-grunt-tasks")(grunt)

    grunt.initConfig({
        pkg: grunt.file.readJSON("package.json"),
        connect: {
            options: {
                base: ['node_modules', 'public'],
                livereload: 8000,
                open: true
                //keepalive: true
            },
            server: {
                port: 8000
            }
        },
        copy: {
            todo: {
                expand: true,
                cwd: "src/todo",
                src: ["**"],
                dest: "public/todo/js/"
            }
        },
        express: {
            options: {
                delay: 0

            },
            dev: {
                options: {
                    script: "src/server.js"
                }

            }
        },
        watch: {
            scripts: {
                files: ['src/**', 'test/**'],
                tasks: ["copy", "karma:unit:run"],
                options: {
                    spawn: false
                }
            }
        },
        karma: {
            unit: {
                configFile: 'test/karma.conf.js',
                background: true,
                autoWatch: false,
                singleRun: false
            }
        }


    })

    grunt.registerTask("default", [ "copy", "connect", "karma:unit:start", "watch"])
}


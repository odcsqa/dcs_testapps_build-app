requirejs.config({
    baseUrl: "js",

    paths: {
        "ojL10n": "/oraclejet/dist/js/libs/oj/ojL10n",
        "ojtranslations": "/oraclejet/dist/js/libs/oj/resources",
        "ojs": "/oraclejet/dist/js/libs/oj/debug",
        promise: '/es6-promise/dist/es6-promise',
        "knockout": '/knockout/build/output/knockout-latest.debug',
        "redux" : '/redux/dist/redux'
    }
})

require(["knockout", "model"], function(ko, Model) {
    ko.applyBindings(new  Model(), document.getElementById("main"))        
})


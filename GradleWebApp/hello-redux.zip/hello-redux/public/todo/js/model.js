
define(["knockout",  "ojs/ojmodule", "redux"], function(ko,  ojModule, redux) {
    
    class State {

        newVariable (name, value=null) {
            let internalValue = ko.observable(value)
            
            console.log('Defining', name, 'with value', value)
            Object.defineProperty(this, name, {
                get: ( ) => {
                    return internalValue()
                },
                set: (value) => {
                    internalValue(value)
                }
            })
        }
    }

    const {createStore}  = redux

    class ToDo {
        constructor (title = "", completed = false) {
            this.state = new State()
            this.state.newVariable('completed', completed)
            //this.completed = completed
            this.state.newVariable('title', title)
            //this.title = title
            this.state.newVariable('selected', false)
            //this.selected = new Variable(false)

            console.log(this.state.title, 'is the title')
        }

    }

    class Model {
        constructor() {
            this.todos = ko.observableArray([new ToDo("Feed the cat", true)])
            this.show = ko.observable("ALL")
        }

        add() {
            this.todos.push(new ToDo())
        }

        remove() {
            let ar = []
            this.todos().map( (v) => {
                if (v.state.selected) {
                    ar.push(v)
                }
            })
            ar.map( v => {
                this.todos.remove(v)
            })
        }

        complete(value) {
            this.todos().map((v) => {
                
                if (v.state.selected) {
                    console.log(v)
                    let n = Object.assign({}, v, { state: { completed: value}})
                    console.log(n)
                    this.todos.replace(v, n)
                }
            })
            
        }

        selected() {
            let i = 0
            this.todos().map((v) => {
                if (v.state.selected) {
                    i++
                }
            })
            return i
        }

        toggle() {
            let value = !(this.selected() > 0)
            this.todos().map((v) => {
                v.state.selected = value
            })
        }

        total() {
            return this.todos().length
        }

    }

    return Model
})


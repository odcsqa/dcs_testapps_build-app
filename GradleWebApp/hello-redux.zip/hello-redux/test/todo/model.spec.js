
define(["public/todo/js/model"], function (Model) {
    describe("Model", function () {
        model = new Model()
        
        it ("can add new entries", function() {
            var i = model.todos().length
            model.add()
            expect(model.todos().length).toBe(i+1)
        })

        it("can remove entries", function() {
            model.todos()[0].state.selected = true
            var i = model.todos().length
            model.remove()
            expect(model.todos().length).toBe(i - 1)
        })
        
    })
})

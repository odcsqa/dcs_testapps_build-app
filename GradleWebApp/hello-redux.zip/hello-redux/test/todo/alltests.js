
requirejs.config({
    baseUrl: '/base',

    paths: {
        "ojL10n": "node_modules/oraclejet/dist/js/libs/oj/ojL10n",
        "ojtranslations": "node_modules/oraclejet/dist/js/libs/oj/resources",
        "ojs": "node_modules/oraclejet/dist/js/libs/oj/debug",
        promise: 'node_modules/es6-promise/dist/es6-promise',
        "knockout": 'node_modules/knockout/build/output/knockout-latest.debug',
        "redux": 'node_modules/redux/dist/redux'
    },

})

require(['test/todo/model.spec'], function() {
    window.__karma__.start()
})
